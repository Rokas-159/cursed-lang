import LangVisitor from './lib/LangVisitor.js';

class LangInterpreter extends LangVisitor {
    constructor() {
        super();
        this.variableTable = {};
    }


    visitProgram(ctx) {
        let result = '';
        for (let i = 0; i < ctx.stat().length; i++) {
            const statementResult = this.visit(ctx.stat(i));
            if (statementResult) {
                result += statementResult;
            }
        }
        return result.trim();
    }

    // Visit a parse tree produced by LangParser#stat.
	visitStat(ctx) {
        if (ctx.PRINT()) {
            return String(this.visit(ctx.expression()));
        } else if (ctx.set_val()) {
            return this.visit(ctx.set_val());
        } else if (ctx.expr()) {
            return this.visit(ctx.expr());
        } else if (ctx.for_loop) {
            return this.visit(ctx.for_loop());
        } else if (ctx.while_loop) {
            return this.visit(ctx.while_loop());
        } else if (ctx.if_stat) {
            return this.visit(ctx.if_stat());
        } else if (ctx.stat()) {
            let result = '';
            for (let i = 0; i < ctx.stat().length; i++) {
                const statementResult = this.visit(ctx.stat(i));
                if (statementResult) {
                    result += statementResult;
                }
            }
            return result.trim();
        }
        return null;
    }


    // Visit a parse tree produced by LangParser#for_loop.
    visitFor_loop(ctx) {
        let result = '';
        for (this.visit(ctx.stat(0)); this.visit(ctx.expr()); this.visit(ctx.stat(1))) {
            const statementResult = this.visit(ctx.stat(2));
            if (statementResult) {
                result += statementResult;
            }
        }
        return result.trim();
    }


    // Visit a parse tree produced by LangParser#while_loop.
    visitWhile_loop(ctx) {
        let result = '';
        while (this.visit(ctx.expr())) {
            const statementResult = this.visit(ctx.stat());
            if (statementResult) {
                result += statementResult;
            }
        }
        return result.trim();
    }


    // Visit a parse tree produced by LangParser#if_stat.
    visitIf_stat(ctx) {
        if (this.visit(ctx.expr())) {
            return this.visit(ctx.stat());
        }
        return null;
    }


    // Visit a parse tree produced by LangParser#set_val.
    visitSet_val(ctx) {
        const varName = ctx.VAL().getText();
        const value = this.visit(ctx.expr());
        this.symbolTable[varName] = value;  // Store the variable in the symbol table
        return value;  // No output for assignments
    }


    // Visit a parse tree produced by LangParser#expr.
    visitExpr(ctx) {
        return this.visit(ctx.equality());
    }


    // Visit a parse tree produced by LangParser#equality.
    visitEquality(ctx) {
        if (ctx.DOUBLE_EQ()) {
            return this.visit(ctx.comparison(0)) == this.visit(ctx.comparison(1));
        } else if (ctx.NOT_EQ()) {
            return this.visit(ctx.comparison(0)) != this.visit(ctx.comparison(1));
        } else {
            this.visit(ctx.comparison(0));
        }
    }


    // Visit a parse tree produced by LangParser#comparison.
    visitComparison(ctx) {
        if (ctx.GR()) {
            return this.visit(ctx.term(0)) > this.visit(ctx.term(1));
        } else if (ctx.GR_EQ()) {
            return this.visit(ctx.term(0)) >= this.visit(ctx.term(1));
        } else if (ctx.LS()) {
            return this.visit(ctx.term(0)) < this.visit(ctx.term(1));
        } else if (ctx.LS_EQ()) {
            return this.visit(ctx.term(0)) <= this.visit(ctx.term(1));
        } else {
            return this.visit(ctx.term(0));
        }
    }


    // Visit a parse tree produced by LangParser#term.
    visitTerm(ctx) {
        if (ctx.MINUS()) {
            return this.visit(ctx.factor(0)) - this.visit(ctx.factor(1));
        } else if (ctx.PLUS()) {
            return this.visit(ctx.factor(0)) + this.visit(ctx.factor(1));
        } else {
            return this.visit(ctx.factor(0));
        }
    }


    // Visit a parse tree produced by LangParser#factor.
    visitFactor(ctx) {
        if (ctx.SLASH()) {
            return this.visit(ctx.unary(0)) / this.visit(ctx.unary(1));
        } else if (ctx.STAR()) {
            return this.visit(ctx.unary(0)) * this.visit(ctx.unary(1));
        } else {
            return this.visit(ctx.unary(0));
        }
    }


    // Visit a parse tree produced by LangParser#unary.
    visitUnary(ctx) {
        if (ctx.MINUS()) {
            return -this.visit(ctx.unary(0));
        } else if (ctx.NOT()) {
            return !this.visit(ctx.unary(0));
        } else {
            return this.visit(ctx.primary(0));
        }
    }


    // Visit a parse tree produced by LangParser#primary.
    visitPrimary(ctx) {
        if (ctx.expr()) {
            return this.visit(ctx.expr());
        } else {
            let value = ctx.VAL();
            if (this.symbolTable.hasOwnProperty(value)) {
                return this.symbolTable[value];  // Retrieve variable value from the symbol table
            } else {
                return this.visit(ctx.VAL());
            }
        }
    }

    visitVAL(ctx) {
        if (ctx.REAL()) {
            return parseFloat(ctx.REAL().getText());
        } else if (ctx.INT()) {
            return parseInt(ctx.INT().getText(), 10);
        } else if (ctx.STRING()) {
            return ctx.STRING().getText().slice(1, -1); // Remove the double quotes
        } else if (ctx.BOOLEAN()) {
            return ctx.BOOLEAN().getText() === 'true';
        }
    }
}

export default LangInterpreter;
